<?php
require('config.php');
if (isset($_POST['books'])) {
    $books = $_POST['books'];
    if (isset($_POST['percentage'])) {
        $percentage = intval($_POST['percentage']);
        foreach ($books as $bid => $price) {
            $price = intval($price);
            $price = $price + ($price * $percentage / 100);
            $sql = "UPDATE books SET price=$price WHERE bid=$bid";
            $res = mysqli_query($link, $sql);
        }
    }
    else{
    foreach ($books as $bid => $price) {
        $price = intval($price);
        $sql = "UPDATE books SET price=$price WHERE bid=$bid";
        $res = mysqli_query($link, $sql);
    }
}
} 

$page_title = 'اصلاح قیمت کتابها';
include('header.php'); ?>
<form action="book-price.php" method="post">
    <table class="table table-bordered">
        <tr>
            <td>شناسه</td>
            <td>نام کتاب</td>
            <td>مؤلف</td>
            <td>قیمت</td>
        </tr>
        <?php
        $sql = "SELECT * FROM books";
        $result = mysqli_query($link, $sql);
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['bid'] ?></td>
                <td><?= $row['bname'] ?></td>
                <td><?= $row['author'] ?></td>
                <td width="300">
                    <input type="text" size="10" name="books[<?= $row['bid'] ?>]" value="<?= $row['price'] ?>"
                        class="form-control" />
                </td>
            </tr>
        <?php } ?>
        <tr colspan="4">
            <div class="form-group">
                <label for="percentage">درصد افزایش </label>
                <input type="text" maxlength="100" name="percentage" />
            </div>
        </tr>
        <tr>
            <td colspan="4">
                <input type="submit" class="btn btn-info" value="ثبت قیمت ها " />
                <input type="reset" class="btn btn-warning" value="بازنویسی " />
            </td>
        </tr>
    </table>

</form>
<?php include('footer.php'); ?>