<?php
$link = mysqli_connect('localhost:3306', 'root', '');
// if ($link) {
//     print "Connection is Success" . "<br>";
// }
$db = mysqli_select_db($link, 'bookshop');
// if ($db) {
//     print "Database is Selected";
// }
?>