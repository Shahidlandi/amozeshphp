<?php
include('config.php');
if (isset($_POST['bname'])) {
    $bname = $_POST['bname'];
    $author = $_POST['author'];
    $price = intval($_POST['price']);
    $sid = $_POST['sid'];
    $fsize = $_FILES['cover']['size'];
    $des = $_POST['des'];
    $status = 0;

    $errors = array();

    if ($bname == '') {
        $errors[] = 'نام کتاب نباید خالی باشد';
    }
    if ($price == '') {
        $errors[] = 'قیمت کتاب نباید خالی باشد';
    }


     if ($_POST['status'])
         $status = 1;

    if ($fsize > 0) {
        $fname = $_FILES['cover']['name'];
        $passvand = explode('.', $fname);
        $ext = end($passvand);
        if ($ext != 'jpg' && $ext != 'png')
            $errors[] = 'پسوند فایل انتخابی اشتباه می باشد';
        if ($fsize > 100 * 1024)
            $errors[] = 'حجم فایل از صد مگ نباید بیشتر باشد';
    }

    if (count($errors) == 0) {
        $tname = $_FILES['cover']['tmp_name'];
        include('config.php');
        $coverName = time() . '-' . $fname;
        move_uploaded_file($tname, "cover/$coverName");
        $resualt = mysqli_query(
            $link,
            "INSERT INTO books(bname,author,price,sid,des,cover,status)
     VALUES('$bname','$author',$price,$sid,'$des','$coverName',$status)" );
        if ($resualt){
            header('location:book-index.php');
        }
    }
}
    
    $page_title = 'افزودن کتاب';
    include('header.php');
    include('show-errors.php');
    ?>
    <form action="book-add.php" method="post" enctype="multipart/form-data">

        <div class="form-group">
            <label for="status">
                قابل نمایش
            </label>
            <input type="checkbox" name="status"  />
        </div>

        <div class="form-group">
            <label for="bname">نام کتاب</label>
            <input type="text" maxlength="100" name="bname" class="form-control" />
        </div>
        <div class="form-group">
            <label for="author">نام مولف</label>
            <input type="text" name="author" class="form-control" />
        </div>
        <div class="form-group">
            <label for="price">قیمت</label>
            <input type="number" name="price" class="form-control" />
        </div>
        <div class="form-group">
            <label for="sid">موضوع کتاب</label>
            <select name="sid" class="form-control">
                <option value="0">---</option>
                <?php
                $res2 = mysqli_query($link, 'SELECT * FROM subs');
                while ($row2 = mysqli_fetch_assoc($res2)) { ?>
                    <option value="<?= $row2['sid']; ?>">
                        <?= $row2['sname']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label for="cover">تصویر جلد</label>
            <input type="file" name="cover" accept=".jpg,.png" class="form-control" />
        </div>
        <div class="form-group">
            <label for="des">توصیف کتاب</label>
            <textarea name="des" rows="5" class="form-control"></textarea>
        </div>
        <div class="form-group">
            <input type="submit" value=" ارسال فرم " class=" btn btn-info" />
            <input type="reset" value=" بازنویسی " class=" btn btn-warning" />
        </div>
    </form>
    <?php
include('footer.php');
?>