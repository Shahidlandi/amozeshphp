<?php
    $bid = 1014;
    include("../config.php");
    $res = mysqli_query($link, "DELETE FROM books WHERE bid=$bid");
    if ($res) {
        print "DELETE Record";
    }
?>