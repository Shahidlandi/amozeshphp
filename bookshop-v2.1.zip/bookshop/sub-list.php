<?php
$page_title = 'مدیریت موضوعات';
include("header.php");
include("config.php");
if (isset($_GET['s'])) {
    $s = $_GET['s']; 
    if ($s == 1) {?>
        <div class="alert alert-success">
       <h3>رکورد با موفقیت اضافه گردید</h3>
       </div>
   <?php }
   if ($s == 2) { ?>
   <div class="alert alert-danger">
       <h3>رکورد با موفقیت حذف گردید</h3>
       </div>
   <?php } 
   if ($s == 3) { ?>
   <div class="alert alert-info">
       <h3>رکورد با موفقیت ویرایش گردید</h3>
       </div>
   <?php } ?>
<script>
   function refreshUrl() {
       window.history.pushState({}, document.title, "sub-list.php");
       window.location.reload();
   }
   setTimeout(refreshUrl, 2000);
</script>  
<?php    
 }
?>
<table class="table table-bordered table-hover table-striped">
    <tr>
        <th>شناسه</th>
        <th>نام موضوع</th>
        <th><a href="sub-add.php">افزودن موضوع</a></th>
    </tr>

    <?php
    $sql = "SELECT * FROM subs";
    $res = mysqli_query($link, $sql);
    while ($row = mysqli_fetch_assoc($res)) { ?>
        <tr>
            <td><?= $row['sid'] ?></td>
            <td><?= $row['sname'] ?></td>
            <td><a href="sub-delete.php?sid=<?= $row['sid'] ?>">حذف</a> |
                <a href="sub-edit.php?sid=<?= $row['sid'] ?>">ویرایش</a>|
                <a href="book-list.php?sid=<?= $row['sid'] ?>">کتاب‌ها</a>
            </td>
        </tr>
        <?php
    }
    ?>

</table>

<?php
include("footer.php");
?>