<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>فروشگاه کتاب اینترنتی</title>
<script src="bs/js/jquery.min.js"></script>
<script src="bs/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="bs/css/bootstrap.min.css">
<link rel="stylesheet" href="bs/css/bootstrap-rtl.min.css">
<link rel="stylesheet" href="css/pstyle.css">
</head>
<body>
<div class="container-fluid header">
<div class="container">
<div class="row">
 <div class="col-5">
 <img src="image/logo.png">
 </div>
<div class="col-7" style="text-align:left">
 <a href=" ">خرید سبد</a>
 <a href="search.php">جستوجو</a>
 <a href="contactus.php">ما با تماس</a>
 <a href="login.php">اعضا ورود</a>
 </div>
</div>

</div>
</div>
<div class="container-fluid navbar">
<div class="container">
<ul>
<li><a href=" ">صفحه اول</a></li>
<li> | <a href=" ">تاریخی</a></li>
<li> | <a href=" ">سیاسی</a></li>
<li> | <a href=" ">اقتصادی</a></li>
</ul>
</div>
</div>
<div class="container-fluid body">
<div class="container">