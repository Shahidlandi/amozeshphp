<?php
    $name = $_FILES['cover']['name'];
    // $type = $_FILES['cover']['type'];
    // $size = $_FILES['cover']['size'];
    // $tmp_name = $_FILES['cover']['tmp_name'];
    // print $name . "<br>";
    // print $type . "<br>";
    // print $size . "<br>";
    // print $tmp_name . "<br>";

    $arr = explode('.',$name);
 
    $pasvand = end($arr);

    if ($pasvand == "png"){
        move_uploaded_file($tmp_name,"pic/$name");
        print "فایل با موفقیت آپلود شد";
    }
    else {
        print "پسوند فایل غیر قابل قبول";
    }
?>