<?php
include('pheader.php');
?>
<h1>لیست کاربران</h1>
<hr>
<table width="600" border="1">
    <tbody>
        <tr>
            <td>شناسه</td>
            <td>نام کاربری</td>
            <td>همراه</td>
            <td>آدرس</td>
        </tr>
        <?php
        include('config.php');
        $result = mysqli_query($link, "SELECT * FROM users");
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?= $row['uid'] ?></td>
                <td><?= $row['uname'] ?></td>
                <td><?= $row['mobil'] ?></td>
                <td><?= $row['addr'] ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
</body>

</html>

<?php
include('pfooter.php');
?>