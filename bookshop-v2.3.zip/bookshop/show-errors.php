<?php 
if ( isset($errors) && count($errors)>0){ ?>
<div class="alert alert-danger">
<?php 
 echo "<ul>";
 foreach($errors as $err) 
 echo "<li>$err</li>"; 
 echo "</ul>";
 ?>
</div>
<?php } ?>