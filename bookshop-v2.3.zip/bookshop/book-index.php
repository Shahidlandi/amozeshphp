<?php
include('pheader.php');
?>

<div class="row">
    <?php
    include('config.php');
    if(isset($_GET['sid'])){
        $sid = $_GET['sid'];
        $result = mysqli_query($link, "SELECT * FROM books WHERE sid=$sid");
    }
    else{
        $result = mysqli_query($link, "SELECT * FROM books");
    }
    
    while ($book = mysqli_fetch_assoc($result)) { ?>
        <div class="col-sm-3">
            <div class="box">
                <a href="book-show.php?bid=<?= $book['bid'] ?>">
                    <img src="cover/<?= $book['cover'] ?>">
                </a>
                <a href="book-show.php?bid=<?= $book['bid'] ?>">
                    <h2 align="center"><?= $book['bname'] ?></h2>
                </a>
            </div>
        </div>
    <?php } ?>
</div>

<?php
include('pfooter.php');
?>