<!doctype html>
<html>

<head>
        <meta charset="utf-8">
        <title>فروشگاه کتاب اینترنتی</title>
        <script src="bs/js/jquery.min.js"></script>
        <script src="bs/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="bs/css/bootstrap.min.css">
        <link rel="stylesheet" href="bs/css/bootstrap-rtl.min.css">
        <link rel="stylesheet" href="css/pstyle.css">
</head>

<body>
        <div class="container-fluid header">
                <div class="container">
                        <div class="row">
                                <div class="col-5">
                                        <img src="image/logo.png">
                                </div>
                                <div class="col-7" style="text-align:left">
                                        <a href=" ">سبد خرید</a>
                                        | <a href="search.php">جستوجو</a>
                                        | <a href="contactus.php">تماس با ما</a>
                                        | <a href="login.php">ورود اعضا</a>
                                </div>
                        </div>

                </div>
        </div>
        <div class="container-fluid navbar">
                <div class="container">
                        <ul>
                                <li>  <a href="index.php">صفحه اول</a></li>
                                <?php
                                include('Config.php');
                                $resualt = mysqli_query($link, 'SELECT * FROM subs');
                                while ($row = mysqli_fetch_assoc($resualt)) { ?>
                                        <li> | <a href="book-index.php?sid=<?= $row['sid']?>"><?= $row['sname'] ?></a></li>
                                        <?php
                                }
                                ?>
                        </ul>
                </div>
        </div>
        <div class="container-fluid body">
                <div class="container">