<?php
$sid = $_GET['sid'];

include('config.php');

$sql = "DELETE FROM subs WHERE sid=$sid";
$res = mysqli_query($link, $sql);
if ($res) {
    $success = 2;
    header("location:sub-list.php?s=$success");
}
?>