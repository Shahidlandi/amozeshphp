<html>
    <body>
        <form action="db-test-add.php" method="get">
            <input type="text" name="username">
            <input type="text" name="password">
            <input type="submit" value="Login">
        </form>
    </body>
</html>