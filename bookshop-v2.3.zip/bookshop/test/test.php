<?php include('pheader.php');
?>

<table border=1px>
    <tr>
        <td>sid</td>
        <td>sname</td>
</tr>
<?php

    include('Config.php');
    $resualt = mysqli_query($link,'SELECT * FROM subs');

    // $row = mysqli_fetch_assoc($resualt);
    // print_r ($row);

while($row = mysqli_fetch_assoc($resualt)){ ?>
<tr>
    <td><?= $row['sid']; ?> </td>
    <td><?= $row['sname']; ?> </td>
</tr>
<?php
}
?>
</table>

<?php include('pfooter.php');?>