<html>

<body>
    <form action="book-add1.php" method="post" enctype="multipart/form-data">
        <input type="text" name="bname" placeholder="نام کتاب">
        <br>
        <input type="text" name="author" placeholder="نام نویسنده">
        <br>
        <input type="number" name="price" placeholder="قیمت کتاب">
        <br>
        <!-- <input type="number" name="sid" placeholder="موضوع کتاب"> -->
        <label for="subs">موضوع :</label>
        <select name="sub" id="subs">
            <option value="0">-----</option>
            <?php
            include('../config.php');
            $resualt = mysqli_query($link, 'SELECT * FROM subs');
            while ($row = mysqli_fetch_assoc($resualt)) { ?>
                <option value=<?= $row['sid'] ?>><?= $row['sname'] ?></option>
            <?php
            }
            ?>
        </select>
        <br>
        <input type="file" name="cover">
        <br>
        <input type="checkbox" name="status">
        <br>
        <textarea name="des" rows="4" cols="50" placeholder="توضیحات"></textarea>
        <input type="submit" value="ثبت اطلاعات">
    </form>
</body>

</html>