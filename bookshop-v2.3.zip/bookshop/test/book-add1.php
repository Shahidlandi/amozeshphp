<?php
    $fsize= $_FILES['cover']['size'];
    if($fsize > 0){
        $fname = $_FILES['cover']['name'];
        $passvand = explode('.',$fname);
        $ext = end($passvand);
        if($ext == 'jpg' || $ext == 'png'){
            $tname = $_FILES['cover']['tmp_name'];
            $newName = time().'-'.$fname;
            move_uploaded_file($tname, "../image/$newName");
        }
    }
?>