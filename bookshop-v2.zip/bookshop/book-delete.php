<?php
$bid = $_GET['bid'];
include('config.php');
$sql = "DELETE FROM books WHERE bid=$bid";
$res = mysqli_query($link, $sql);
if ($res) {
    header("location:book-list.php");
    // echo "رکورد با موفقیت حذف شد";
}
?>