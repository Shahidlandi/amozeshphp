<?php include('pheader.php');
?>
بدنه صفحه
<?php include('pfooter.php');?>