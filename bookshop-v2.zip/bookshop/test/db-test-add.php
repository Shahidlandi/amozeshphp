<?php 
    $link = mysqli_connect('localhost:3306', 'root', '','test');
    $username=$_GET['username'];
    $password=$_GET['password'];
    $sql = "SELECT * FROM user WHERE username=$username AND password=$password";

    
    // INSERT
    // $username=$_GET['username'];
    // $password=$_GET['password'];

    // $SqlInsert = "INSERT INTO user(username,password) VALUES('$username','$password')";
    // $re= mysqli_query($link,$SqlInsert);

?>
