<?php
$page_title = 'حذف کتاب';
include("header.php");
include("config.php");
?>
<table  class="table table-bordered table-hover table-striped">
    <tr>
        <th>شناسه</th>
        <th>نام کتاب</th>
        <th>مولف</th>
        <th>قیمت</th>
        <th>موضوع</th>
        <th><a href="book-add.php">افزودن کتاب</a></th>
    </tr>

    <?php
    $res = mysqli_query( $link, "SELECT * FROM books");
    while ($row = mysqli_fetch_assoc($res)) { ?>
        <tr>
            <td><?= $row['bid'] ?></td>
            <td><?= $row['bname'] ?></td>
            <td><?= $row['author'] ?></td>
            <td><?= $row['price'] ?></td>
            <td><?= $row['sid'] ?></td>
            <td><a href="book-delete.php?bid=<?= $row['bid'] ?>">حذف</a> | 
            <a href="book-edit.php?bid=<?= $row['bid'] ?>">ویرایش</a></td>
        </tr>
        <?php
    }
    ?>

</table>

<?php

include("footer.php");
?>