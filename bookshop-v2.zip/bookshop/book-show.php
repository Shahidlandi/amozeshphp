<?php
include('pheader.php');
$bid = $_GET['bid'];

include('config.php');

$result = mysqli_query($link, "SELECT * FROM books where bid=$bid ");
$book = mysqli_fetch_assoc($result); ?>
<div class="row">
    <div class="col-sm-4">
        <img src="cover/<?= $book['cover'] ?>" class="img-fluid">
        <h3>مولف:<?= $book['author'] ?></h3>
        <h3>قیمت:<?= $book['price'] ?></h3>
    </div>
    <div class="col-sm-8">
        <h1><?= $book['bname'] ?></h1>
        <?= nl2br($book['des']) ?>
    </div>
</div>

<?php
include('pfooter.php');
?>