<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title>فروشگاه کتاب اینترنتی</title>
    <script src="./bs/js/jquery.min.js"></script>
    <script src="./bs/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="./bs/css/bootstrap.min.css">
    <link rel="stylesheet" href="./bs/css/bootstraprtl.min.css">
    <link rel="stylesheet" href="css/style.css" />

</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-2 sidebar">
                <h3>
                    <img src="image/logo.png" class="logo" /><br>
                    فروشگاه کتاب
                </h3>
                <ul>
                    <li><a href="home.php">پیشخوان</a></li>
                    <li><a href="profile.php">پروفایل</a></li>


                    <li><a href="password.php">عبور کلمه تغییر</a></li>
                    <li><a href="my-orders.php">من سفارشات</a></li>
                    <li><a href="book-list.php">مدیریت کتاب ها</a></li>
                    <li><a href="sub-list.php">موضوعات مدیریت</a></li>
                    <li><a href="user-list.php">مشتریان مدیریت</a></li>
                    <li><a href="order-list.php">سفارشات مدیریت</a></li>
                </ul>
            </div>
            <div class="col-sm-10 main">
                <div class="header">
                    <?= $page_title ?>
                    <span class="user">نام کاربری</span>
                </div>
                <div class="content">