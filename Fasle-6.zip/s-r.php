<?php

if(isset($_POST['user']) && isset($_POST['pass'])){
    $a = $_POST['user'];
    $b = $_POST['pass'];

    if($a == "admin" && $b == "123"){

        print "Welcome $a";

    }else{

        print "Username OR Password invalid";

    }
}
else { ?>

    <form action="s-r.php" method="post">

    Username : <input type="text" name="user">
    <br>
    Password : <input type="password" name="pass">
    <br>
    <input type="submit" value="send">
    </form>
<?php } ?>