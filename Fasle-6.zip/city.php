<?php
    $city = [
            "1" => "یزد",
            "2" => "تهران",
            "3" => "اصفهان",
            "4" => "قزوین"
    ];
    asort($city);
?>
<select name="city">
    <option value="0"> ---- </option>
    <?php 
        foreach($city as $cityId => $cityName) { ?>
            <option value="<?= $cityId ?>"> <?= $cityName ?> </option>
         <?php } ?>
</select>