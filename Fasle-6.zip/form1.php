<form action="form1.php" method="get">
    UserName: <input type="text" name="user">
    Password: <input type="password" name="pass">
    <input type="checkbox" name="course" value="word"> word
    <input type="checkbox" name="course" value="excel"> excel
    <input type="submit" value="Send">
</form>

