        <form action="recive-data.php" method="post">

        Username : <input type="text" name="user">
        <br>
        Password : <input type="password" name="pass">
        <br>
        <input type="submit" value="send">
        </form>


