<?php
    $a = $_POST['user'];
    $b = $_POST['pass'];

if($a == "admin" && $b == "123"){

    print "Welcome $a";

}else{

    print "Username OR Password invalid";

}
    // print "Username is : $a <br>";
    // print "Pasword is : $b";
?>