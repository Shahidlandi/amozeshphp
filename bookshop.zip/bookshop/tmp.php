<?php 
$page_title="عنوان صفحه";
include('header.php');
?>
بدنه صفحه
<?php include('footer.php');?>