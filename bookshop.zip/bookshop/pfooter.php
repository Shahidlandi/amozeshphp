</div>
</div>
<div class="container-fluid footer1">
<div class="container">
<h5>آدرس فروشگاه</h5>
تهران، منطقه ،50 محله ،43 خیابان یکم، تلفن 0123456
</div>
</div>
<div class="container-fluid footer2">
<div class="container">
تمام حقوق این سایت متعلق به فروشگاه کتاب است.
</div>
</div>
</body>
</html>