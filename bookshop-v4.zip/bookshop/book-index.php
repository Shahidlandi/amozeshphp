<?php
include('pheader.php');
?>
<!-- ********************************* -->
<h1 class="h1">تازه ترین کتابها</h1>
<div class="row">
    <?php
    require_once('config.php');
    $sql = "SELECT * FROM books WHERE status=1 ORDER By bid DESC LIMIT 0,2";
    $res = mysqli_query($link, $sql);
    while ($row = mysqli_fetch_assoc($res)) { ?>
        <div class="col-sm-3">
            <div class="box">
                <a href="book-show.php?bid=<?= $row['bid'] ?>">
                    <img src="cover/<?= $row['cover'] ?>">
                    <strong><?= $row['bname'] ?></strong>
                </a><br>
                <span><?= $row['price'] ?>ریال</span>
            </div>
        </div>
    <?php } ?>
</div>
<!-- ******************************* -->
<h1 class="h1"> کتابها</h1>
<div class="row">
    <?php
    include('config.php');
    if (isset($_GET['sid'])) {
        $sid = $_GET['sid'];
        $result = mysqli_query($link, "SELECT * FROM books WHERE sid=$sid");
    } else {
        $result = mysqli_query($link, "SELECT * FROM books");
    }

    while ($book = mysqli_fetch_assoc($result)) { ?>
        <div class="col-sm-3">
            <div class="box">
                <a href="book-show.php?bid=<?= $book['bid'] ?>">
                    <img src="cover/<?= $book['cover'] ?>">
                </a>
                <a href="book-show.php?bid=<?= $book['bid'] ?>">
                    <h2 align="center"><?= $book['bname'] ?></h2>
                </a>
            </div>
        </div>
    <?php } ?>
</div>

<?php
include('pfooter.php');
?>