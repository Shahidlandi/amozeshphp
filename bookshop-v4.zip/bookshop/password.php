<?php
$role = '';
include('check.php');
require('config.php');
$errors = [];
$uid = $_SESSION['user']['uid'];
if (isset($_POST['pass'])) {
    $pass = $_POST['pass'];
    $pass1 = $_POST['pass1'];
    $pass2 = $_POST['pass2'];
    if ($pass != $_SESSION['user']['pass'])
        $errors[] = 'رمز عبور قبلی نادرست است';
    if (strlen($pass1) < 6)
        $errors[] = 'طول رمز عبور نباید از 6 کاراکتر کمتر باشد';
    if ($pass1 != $pass2)
        $errors[] = 'رمز عبور و تکرار آن یکسان نیست';
    if (count($errors) == 0) {
        $sql = "UPDATE `users` SET pass='$pass1' WHERE uid=$uid ";
        $res = mysqli_query($link, $sql);
        if ($res) {
            $_SESSION['fb'] = 'رمز عبور شما با موفقیت تغییر کرد';
            header('location:home.php');

        } else {
            $errors[] = 'تغییر رمز عبور با خطا مواجه شد';
        }
    }
}
$page_title = 'عبور کلمه تغییر';
include('header.php');
include('show-errors.php');
$res = mysqli_query($link, "SELECT * FROM users WHERE uid=$uid ");
$row = mysqli_fetch_assoc($res);
?>
<form action="password.php" method="post">
    <div class="form-group">
        <label for="author">همراه شماره</label>
        <input readonly type="text" name="mobile" value="<?= $row['mobil'] ?>" class="form-control" />
    </div>
    <div class="form-group">
        <label for="pass1">قبلی عبور رمز</label>
        <input type="password" name="pass" class="form-control" />
    </div>
    <div class="form-group">
        <label for="pass">جدید عبور رمز</label>
        <input type="password" name="pass1" class="form-control" />
    </div>
    <div class="form-group">
        <label for="pass2">عبور رمز تکرار</label>
        <input type="password" name="pass2" class="form-control" />
    </div>
    <div class="form-group">
        <input type="submit" value="عبور رمز تغییر " class="btn btn-info" />
    </div>
</form>
<?php include('footer.php'); ?>