<?php

$role ='admin';
include('check.php');

$page_title = 'مدیریت کتاب';
include("header.php");
include("config.php");


if(isset($_SESSION['msg']) ){
?>

<div class="alert alert-success ">
<?php
 echo $_SESSION['msg'];
 unset ($_SESSION ['msg']);
 
?>
</div>
<?php } ?>

<table class="table table-bordered table-hover table-striped">
    <tr>
        <th>شناسه</th>
        <th>نام کتاب</th>
        <th>مولف</th>
        <th>قیمت</th>
        <th>موضوع</th>
        <th><a href="book-add.php">افزودن کتاب</a>
            <br>
            <a href="book-price.php">اصلاح گروهی قیمت کتاب</a>
        </th>
    </tr>

    <?php
    if (isset($_GET['sid'])) {
        $sid = $_GET['sid'];

        $res = mysqli_query($link, "SELECT * FROM books WHERE sid=$sid");
        while ($row = mysqli_fetch_assoc($res)) { ?>
            <tr>
                <td><?= $row['bid'] ?></td>
                <td><?= $row['bname'] ?></td>
                <td><?= $row['author'] ?></td>
                <td><?= $row['price'] ?></td>
                <td><?= $row['sid'] ?></td>
                <td><a href="book-delete.php?bid=<?= $row['bid'] ?>">حذف</a> |
                    <a href="book-edit.php?bid=<?= $row['bid'] ?>">ویرایش</a>
                </td>
            </tr>
            <?php
        }
    } else {
        $res = mysqli_query($link, "SELECT * FROM books");
        while ($row = mysqli_fetch_assoc($res)) { ?>
            <tr>
                <td><?= $row['bid'] ?></td>
                <td><?= $row['bname'] ?></td>
                <td><?= $row['author'] ?></td>
                <td><?= $row['price'] ?></td>
                <td><?= $row['sid'] ?></td>
                <td><a href="book-delete.php?bid=<?= $row['bid'] ?>">حذف</a> |
                    <a href="book-edit.php?bid=<?= $row['bid'] ?>">ویرایش</a>
                </td>
            </tr>

            <?php
        }
    }
    ?>

</table>

<?php

include("footer.php");
?>