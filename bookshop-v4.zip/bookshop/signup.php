<?php

  include('config.php');

  if(isset($_POST['mobile'])){
    $fullname = $_POST['fullName'];
    $mobile = $_POST['mobile'];
    $password = $_POST['password'];
    $address = $_POST['address'];

    $sql = "INSERT INTO users(uname,mobil,addr,pass)
     VALUES('$fullname','$mobile','$address','$password')";
     $res = mysqli_query($link,$sql);

     if($res){
      header("location:login.php");
     }
  }

?>




<html lang="en" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> فرم ثبت نام  </title>
  <link rel="stylesheet" href="./css/loginStyle.css">
</head>
<body>
  <div class="container">
    <!-- Title section -->
    <div class="title">ثبت نام</div>
    <div class="content">
      <!-- Registration form -->
      <form action="signup.php" method="post">
        <div class="user-details">
          <!-- Input for Full Name -->
          <div class="input-box">
            <span class="details">نام و نام خانوادگی</span>
            <input type="text" name="fullName" placeholder="نام و نام خانوادگی را وارد کنید" required>
          </div>
          <!-- Input for Mobile -->
          <div class="input-box">
            <span class="details">موبایل</span>
            <input type="text" name="mobile" placeholder="موبال را وارد کنید" required>
          </div>
          <!-- Input for Password -->
          <div class="input-box">
            <span class="details">رمز عبور</span>
            <input type="text" name="password" placeholder="رمز عبور را وارد نمایید" required>
          </div>
          <!-- Input for Address -->
          <div class="input-box">
            <span class="details">آدرس</span>
            <input type="text" name="address" placeholder="آدرس را وارد نماید" required>
          </div>
        </div>
        </div>
        <!-- Submit button -->
        <div class="button">
          <input type="submit" value="ثبت نام">
          <input type="reset" value="پاک کردن فرم">
        </div>
      </form>
    </div>
  </div>
</body>
</html>