<?php
session_start();
$bid = $_GET['bid'];
include('config.php');
if (isset($_POST['bname'])) {
    //پردازش دادههای فرم
    $bname = $_POST['bname'];
    $author = $_POST['author'];
    $price = intval($_POST['price']);
    $sid = $_POST['sid'];
    $des = $_POST['des'];
    $cover1 = $_POST['cover1'];
    $cover = $_FILES['cover2'];
    $status = 0;
    if (isset($_POST['status']))
        $status = 1;
    $errors = array();
    if ($bname == ' ')
        $errors[] = 'نام کتاب تعیین نشده است';
    if ($price == 0)
        $errors[] = 'قیمت کتاب نامعتبر است';
    $fsize = $_FILES['cover2']['size'];
    $fname = ' ';
    if ($fsize > 0) {
        $fname = $_FILES['cover2']['name'];
        $tname = $_FILES['cover2']['tmp_name'];
        $arr = explode('.', $fname);
        $ext = end($arr);
        if ($ext != 'jpg' && $ext != 'png')
            $errors[] = 'فرمت فایل غیر مجاز است';
        if ($fsize > 100 * 1024)
            $errors[] = 'اندازه فایل بیش از حد مجاز است';
    }
    if (count($errors) == 0) {
        if ($fname != '') {
            @unlink("cover/$cover1");
            $cover = time() . '-' . $fname;
            move_uploaded_file($tname, "cover/$cover");
        }
        $sql = "UPDATE books 
 SET bname='$bname',author='$author'
 ,price=$price ,sid=$sid,des='$des'
 ,status=$status,cover='$cover'
 WHERE bid=$bid";
        $res = mysqli_query($link, $sql);
        if ($res){
        $_SESSION['msg']="رکورد با موفقیت ویرایش شد";
            header("location:book-list.php");
        }else
            echo mysqli_error($link);
    }
} else {
    $page_title = 'ویرایش اطلاعات کتاب';
    include('header.php');
    $result = mysqli_query($link, "SELECT * FROM books WHERE bid=$bid");
    $row = mysqli_fetch_assoc($result);
    ?>
    <form action="book-edit.php?bid=<?=$row['bid']?>" method="post" enctype="multipart/form-data">

        <div class="form-group">
            <input type="checkbox" name="status" <?php if ($row['status'] == 1)
                echo 'checked'; ?> />
            <label for="status">
                قابل نمایش
            </label>
        </div>


        <div class="form-group">
            <label for="bname">نام کتاب</label>
            <input type="text" name="bname" value="<?= $row['bname'] ?>" class="form-control" / </div>

            <div class="form-group">
                <label for="author">نام مولف</label>
                <input type="text" name="author" value="<?= $row['author'] ?>" class="form-control" / </div>

                <div class="form-group">
                    <label for="price">قیمت</label>
                    <input type="number" name="price" value="<?= $row['price'] ?>" class="form-control" />
                </div>



                <div class="form-group">
                    <label for="sid">موضوع کتاب</label>
                    <select name="sid" class="form-control">
                        <option value="0">---</option>
                        <?php
                        $res2 = mysqli_query($link, 'SELECT * FROM subs');
                        while ($row2 = mysqli_fetch_assoc($res2)) { ?>
                            <option value="<?= $row2['sid']; ?>" <?php if ($row['sid'] == $row2['sid'])
                                  echo 'selected'; ?>>
                                <?= $row2['sname']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="cover">تصویر جلد کتاب</label>
                    <?php if ($row['cover'] != '') ?>
                        <img src="cover/<?= $row['cover'] ?>" width="150" height="150">
                  
                    <br><br>
                    <input type="hidden" name="cover1" value="<?= $row['cover'] ?>" />
                    <input type="file" id="cover" name="cover2" accept=".jpg,.png" class="form-control" />
                </div>
                <div class="form-group">
                    <label for="des">توصیف کتاب</label>
                    <textarea name="des" rows="5" class="form-control">><?=$row['des']?></textarea>
                </div>
                <div class="form-group">
                    <input type="submit" value=" به روز رسانی " class=" btn btn-info" />
                    <input type="reset" value=" بازنویسی " class=" btn btn-warning" />
                </div>
    </form>
    <?php
}
include('footer.php');
?>