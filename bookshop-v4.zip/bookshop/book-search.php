<?php
$page_title="جستجوی کتاب";

include('header.php');
include('config.php');
// Serch Code
$srch ='';
$price1 = '';
$price2='';
$sql = "SELECT * FROM books WHERE 1=1";
if(isset($_POST['srch'])){
    $srch = $_POST['srch'];
    $price1 = $_POST['price1'];
    $price2 = $_POST['price2'];

    
    if($srch != ''){
        $sql.=" AND (bname LIKE '%$srch%')";
    }
    if($price1 != ''){
        $sql.=" AND price >= $price1";
    }
    if($price2 != ''){
        $sql.=" AND price <= $price2";
    }
}
?>
<!-- Book Serach Code -->
<form sction="book-search.php" method="post">
    <div class="row">
        <div class="col-sm-1">عبارت</div>
            <div class="col-sm-3">
                <input type="text" name="srch" value="<?= $srch ?>" class="form-control">
            </div>
            <div class="col-sm-1">قیمت از</div>
                <div class="col-sm-2">
                    <input type="number" name="price1" size="10"  value="<?= $price1 ?>" class="form-control" />
                </div>
                <div class="col-sm-1">قیمت تا</div>
                    <div class="col-sm-2">
                        <input type="number" name="price2" size="10" value="<?= $price2 ?>" class="form-control" />
                    </div>
                    <div class="col-sm-2">
                        <input type="submit" value="جستوجو " class="btn btn-info" />
                    </div>
                </div>
</form>
<table class="table table-bordered table-hover table-striped">
    <tr>
        <th>شناسه</th>
        <th>نام کتاب</th>
        <th>مولف</th>
        <th>قیمت</th>
        <th>موضوع</th>
    </tr>
<?php
$res = mysqli_query($link, $sql);

while($row = mysqli_fetch_assoc($res)){ ?>
    <tr>
        <td><?= $row['bid'] ?></td>
        <td><?= $row['bname'] ?></td>
        <td><?= $row['author'] ?></td>
        <td><?= $row['price'] ?></td>
        <td><?= $row['sid'] ?></td>
    </tr>
<?php
}
?>
<!-- End Serach -->
 </table>