<?php
$role = '';
include('check.php');
$page_title = "پیشخوان";
include('header.php'); ?>
<h1>
    کاربر عزیز خوشآمدید
</h1>
<?php
include('footer.php');
?>