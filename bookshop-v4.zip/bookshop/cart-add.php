<?php
session_start();

$bid = $_GET['bid'];
$count = $_POST['count'];

if(isset($_SESSION['cart'])){
    $cart= $_SESSION['cart'];
}
else{
    $cart = array();

}
if(isset($cart[$bid])){
    print "این کتاب قبلا ثبت شده است";
}else $cart[$bid]=$count;

$_SESSION['cart']= $cart;

print_r($cart);
// header("location:book-show.php?bid=$bid");

?>
