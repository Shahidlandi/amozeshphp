<?php
$page_title = 'ویرایش موضوعات';
include('header.php');
include('config.php');
$sid = $_GET['sid'];

if(isset($_POST['sname'])){
    $sname = $_POST['sname'];
    $sql="UPDATE subs SET sname='$sname' WHERE sid=$sid";
    $res= mysqli_query($link,$sql);
    header("location:sub-list.php?s=3");

}


$sql1 = "SELECT * FROM subs WHERE sid= $sid";
$res1 = mysqli_query($link, $sql1);
$row = mysqli_fetch_assoc($res1);
?>
<form action="sub-edit.php?sid=<?= $row['sid'] ?>" method="post">
    <div class="form-group">
        <label for="sname">موضوع</label>
        <input type="text" name="sname" value="<?= $row['sname'] ?>" class="form-control" />
    </div>
    <div class="form-group">
        <input type="submit" value=" ویرایش " class=" btn btn-info" />
        <input type="reset" value=" بازنویسی " class=" btn btn-warning" />
    </div>
</form>
<?php
include('footer.php');
?>