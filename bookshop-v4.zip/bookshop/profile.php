<?php
session_start();
$page_title = "ویرایش پروفایل";

include('header.php');
include('config.php');


if (isset($_POST['fullName'])) {
    $fullName= $_POST['fullName'];
    $fname = $_FILES['picture']['name'];
    $tname = $_FILES['picture']['tmp_name'];
    $uid = $_SESSION['user']['uid'];


        $picName = time() . '-' . $fname;
        move_uploaded_file($tname, "profilePic/$picName");
        $sql ="UPDATE users SET uname='$fullName', pic='$picName' WHERE uid=$uid";
        $resualt = mysqli_query($link,$sql);
        if($resualt){
            print "aaaaa";
        }
    }
?>

<form action="profile.php" method="post" enctype="multipart/form-data">
    <img src="./profilePic/<?= $_SESSION['user']['pic'] ?>">
    <div class="form-group">
        <label for="status">
            تصویر
        </label>
        <input type="file" name="picture"  accept=".jpg,.png">
    </div>
    <div class="form-group">
        <label for="status">
            نام مشتری
        </label>
        <input type="text" name="fullName" value="<?php echo $_SESSION['user']['uname'] ?>" required>
    </div>

    <div class="form-group">
        <label for="status">
            شماره همراه
        </label>
        <input type="text" name="mobil" readonly value="<?php echo $_SESSION['user']['mobil'] ?>">
    </div>
    <div class="form-group">
            <input type="submit" value="ثبت تغییرات " class=" btn btn-info" />
        </div>
</form>
<?php
include('footer.php');
?>