<?php
    session_start();
    include('config.php');
    if(isset($_POST['mobile'])){
        $mobile = $_POST['mobile'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE mobil='$mobile' AND pass='$password'";
        $res = mysqli_query($link,$sql);
        $row = mysqli_fetch_assoc($res);
        if($row){
            $_SESSION['user']= $row;
            header("location:home.php");
        }
    }
?>



<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> فرم ثبت نام </title>
    <link rel="stylesheet" href="./css/loginStyle.css">
</head>

<body>
    <div class="container">
        <!-- Title section -->
        <div class="title">ورود به سایت</div>
        <div class="content">
            <!-- Registration form -->
            <form action="login.php" method="post">
                <div class="user-details">
                    <!-- Input for Full Name -->
                    <div class="input-box">
                        <span class="details">نام کاربری</span>
                        <input type="text" name="mobile" placeholder="نام کاربری را وارد کنید" required>
                    </div>
                    <!-- Input for Mobile -->
                    <div class="input-box">
                        <span class="details">رمز عبور</span>
                        <input type="password" name="password" placeholder="رمز عبور را وارد کنید" required>
                    </div>
                    <div class="button">
                        <input type="submit" value="ورود">
                    </div>
            </form>
        </div>
    </div>
</body>

</html>