<?php
include('pheader.php');
$bid = $_GET['bid'];

include('config.php');

$result = mysqli_query($link, "SELECT * FROM books where bid=$bid ");
$book = mysqli_fetch_assoc($result); ?>
<div class="row">
    <div class="col-sm-4">
        <img src="cover/<?= $book['cover'] ?>" class="img-fluid">
        <h3>مولف:<?= $book['author'] ?></h3>
        <h3>قیمت:<?= $book['price'] ?></h3>
    </div>
    <div class="col-sm-8">
        <h1><?= $book['bname'] ?></h1>
        <?= nl2br($book['des']) ?>
    </div>
    <form action="cart-add.php?bid=<?= $book['bid'] ?>" method="post">
    <label for="number">تعداد قابل سفارش</label>
    <input type="number" name="count" id="number" value="1">
    <br>
    <input type="submit" value="افزودن به سبد" class="btn btn-success">
</form>
</div>



<?php
include('pfooter.php');
?>