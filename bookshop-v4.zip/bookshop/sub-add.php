<?php
$page_title = 'افزودن موضوع';
include('header.php');
include('config.php');
if(isset($_POST['sname'])){
    $sname = $_POST['sname'];
    $errors= array();

    if ($sname == '') {
        $errors[]= 'عنوان موضوع نباید خالی باشد';
        include('show-errors.php');
    }
    else{
    $sql = "INSERT INTO subs (sname) VALUE ('$sname')";
    $res = mysqli_query($link,$sql);
    if ($res) {
        $success = 1;
        header("location:sub-list.php?s=$success");
    }
    ?>
    <!-- <div class="alert alert-success">
            <h3>رکورد با موفقیت اضافه گردید</h3>
    </div> -->
<?php
    }
}
?>
    
<form action="sub-add.php" method="post">
    <div class="form-group">
        <label for="sname">عنوان موضوع</label>
        <input type="text" maxlength="20" name="sname" class="form-control" />
    </div>


    <div class="form-group">
        <input type="submit" value=" ارسال فرم " class=" btn btn-info" />
        <input type="reset" value=" بازنویسی " class=" btn btn-warning" />
    </div>
</form>
<?php
include('footer.php');
?>