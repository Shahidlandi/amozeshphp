<?php
session_start();
$bid = $_GET['bid'];
include('config.php');
$sql = "DELETE FROM books WHERE bid=$bid";
$res = mysqli_query($link, $sql);
if ($res) {
    $_SESSION['msg']="رکورد با موفقیت حذف شد";
    header("location:book-list.php");
   
}
?>