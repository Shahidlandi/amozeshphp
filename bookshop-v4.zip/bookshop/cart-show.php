<?php
session_start();
include("pheader.php");
include("config.php");
if(isset($_POST['cart'])){
    $_SESSION['cart'] = $_POST['cart'];
}
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) == 0) {
    print "<h5 class='title1'>سبد خرید شما خالی است</h5>";
} else { ?>
    <h1 class="title2">سبد خرید</h1>
    <?php
    $cart = $_SESSION['cart'];
    $total = 0;
    ?>
    <form action="cart-show.php" method="post">
    <table class="table table-bordered">
        <tr>
            <td>شناسه</td>
            <td>نام کتاب</td>
            <td>قیمت</td>
            <td>تعداد کتاب</td>
        </tr>
        <?php
        foreach ($cart as $bid => $qty) {
            $sql = "SELECT * FROM books WHERE bid=$bid";
            $res = mysqli_query($link, $sql);
            $row = mysqli_fetch_assoc($res);
            $total+= $qty * $row['price'];
            ?>
            <tr>
                <td><?= $bid ?></td>
                <td><?= $row['bname'] ?></td>
                <td><?= $row['price'] ?></td>
                <td><input type="text" name="cart[<?= $bid ?>]" value="<?= $qty ?>" class="form-control"></td>
            </tr>
            <!-- print "$bid" . "==>" . "$qty" . "<br>"; -->
            <?php
        }
}

?>
<tr>
    <td colspan="3"><?= number_format( $total) ?>  ریال</td>
    <td><input type="submit" value="اعمال تغییرات" class="btn btn-info"></td>
</tr>
</table>
</form>
<?php
include("pfooter.php");
?>