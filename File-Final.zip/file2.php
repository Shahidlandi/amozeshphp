<?php
    $cover_name = $_FILES['cover']['name'];
    $cover_size = $_FILES['cover']['size'];
    $cover_tmp = $_FILES['cover']['tmp_name'];

    $content_name = $_FILES['content']['name'];
    $content_size = $_FILES['content']['size'];
    $content_tmp = $_FILES['content']['tmp_name'];

    
    $error =  array();

    //جدا سازی نام را از پسوند فایل
    $cover_arr = explode('.',$cover_name);
    $cover_passvand = end($cover_arr);

    $content_arr = explode('.',$content_name);
    $content_passvand = end($content_arr);


    if( $cover_passvand !="jpg" || $content_passvand!="png" ){
        $error[]="پسوند فایل غیر قابل قبول است";
    }

    if($cover_size > 100 * 1024){
        $error[]="اندازه تصویر جلد کتاب بیشتر از حد مجاز می باشد";
    }

    if($content_size > 500 * 1024){
        $error[]="اندازه تصویر محتوا کتاب بزرگتر از حد مجاز است";
    }

    if(count($error) == 0){
        move_uploaded_file($cover_tmp,"pic/$cover_name");
        move_uploaded_file($content_tmp,"pic/$content_name");
        print "فایل با موفقیت آپلود شد";
    }
    else{
        foreach($error as $err){
            print $err . "<br>";
        }
    }

?>