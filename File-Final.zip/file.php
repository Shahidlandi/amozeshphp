<form action="file2.php" method="post" enctype="multipart/form-data">

    جلد کتاب: <input type="file" name='cover' accept="image/jpeg">
   
    <br>

    محتوا کتاب: <input type="file" name='content' accept="image/png">
    
    <br>

    <input type="submit" >
</form>